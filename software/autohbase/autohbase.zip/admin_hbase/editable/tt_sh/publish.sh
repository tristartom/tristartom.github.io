#!/bin/bash
echo "./tt_sh/publish.sh"

zip_filename=hbaseAdminAndUtil_notYetConfigured.zip
cd ..
zip $zip_filename editable -r -x "editable/src/*" "editable/config.properties"
mv $zip_filename outputs
