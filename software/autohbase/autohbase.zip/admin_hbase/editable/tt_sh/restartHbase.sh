#!/usr/bin/env bash
if [ $# -ne 1 ]; then
  echo "format: ./tt_sh/restartHbase.sh if_load_coprocessor"
  echo "example_1: ./tt_sh/restartHbase.sh yes"
  exit 1
fi
if_load_coprocessor=$1
./tt_sh/stopHbase_normalThenKilljava_verified.sh
./tt_sh/startHbase_verified.sh 120 $if_load_coprocessor
