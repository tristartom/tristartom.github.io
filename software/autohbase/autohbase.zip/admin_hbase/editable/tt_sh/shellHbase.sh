#!/usr/bin/env bash
config_file=config.properties
hbase_all_deployedProjDir=$(awk -F "=" '/^hbase_all_deployedProjDir=.*/ {print $2}' $config_file)
hbase_all_deployedRunnableDir=${hbase_all_deployedProjDir}editable/hbase-configured/
cd $hbase_all_deployedRunnableDir
./bin/hbase shell

