#!/usr/bin/env bash
if [ $# -ne 2 ]; then
  echo "format: ./tt_sh/startHbase_verified.sh time_to_wait if_load_coprocessor[yes|else]"
  echo "example: ./tt_sh/startHbase_verified.sh 60 yes"
  exit 1
fi

wait_time=$1
if_load_coprocessor=$2

config_file=config.properties
hbase_all_deployedProjDir=$(awk -F "=" '/^hbase_all_deployedProjDir=.*/ {print $2}' $config_file)
hbase_all_deployedRunnableDir=${hbase_all_deployedProjDir}editable/hbase-configured/
hbase_regionserver_hostnames=$(awk -F "=" '/^hbase_regionserver_hostnames=.*/ {print $2}' $config_file)
hbase_user=$(awk -F "=" '/^hbase_user=.*/ {print $2}' $config_file)
IFS=':' read -ra hbase_regionserver_hostname_array <<< "$hbase_regionserver_hostnames"
num_regionservers=${#hbase_regionserver_hostname_array[@]}

cur_dir=$(pwd)
#start @master node
cd $hbase_all_deployedRunnableDir
./bin/start-hbase.sh

#verified @master node
echo "@$(hostname)"
jps
#verified @slave nodes
index=0
while [ $index -lt $num_regionservers ]; do
  hbase_regionserver_hostname=${hbase_regionserver_hostname_array[index]}
  echo "@$hbase_regionserver_hostname"
  ssh $hbase_user@$hbase_regionserver_hostname jps
  let index=index+1 
done

echo "sleep for $wait_time sec for hbase to fully start up, before ready to update coprocessor. "
echo " 5 min may be needed, for loading dataset to a different cluster, like 1-master-1-slave cluster"
sleep $wait_time
cd $cur_dir

#start with coprocessor updated
if [ "$if_load_coprocessor" == 'yes' ]; then
  ./tt_sh/initialHIndex.sh
fi
