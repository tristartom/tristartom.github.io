#!/usr/bin/env bash
if [ $# -ne 0 ]; then
  echo "format: ./tt_sh/stopHbase_normalThenKilljava_verified.sh"
  exit 1
fi

config_file=config.properties
hbase_all_deployedProjDir=$(awk -F "=" '/^hbase_all_deployedProjDir=.*/ {print $2}' $config_file)
hbase_all_deployedRunnableDir=${hbase_all_deployedProjDir}editable/hbase-configured/
hbase_regionserver_hostnames=$(awk -F "=" '/^hbase_regionserver_hostnames=.*/ {print $2}' $config_file)
hbase_user=$(awk -F "=" '/^hbase_user=.*/ {print $2}' $config_file)
IFS=':' read -ra hbase_regionserver_hostname_array <<< "$hbase_regionserver_hostnames"
num_regionservers=${#hbase_regionserver_hostname_array[@]}

cd $hbase_all_deployedRunnableDir
#give hbase 60 sec to stop. if not succeed, kill java

/usr/bin/expect -c '
  set timeout 60
  puts "try stop hbase properly; wait till timeout, then force to stop the spawned process"
  spawn ./bin/stop-hbase.sh
  expect eof {puts "\rexpect: hbase stop normally\r"} timeout {puts "\rexpect: hbase stop by timeout\r"; close}
'

hangs_zookeeper=$(jps | grep HQuorumPeer)
hangs_master=$(jps | grep HMaster)
hangs_regionserver=$(jps | grep HRegionServer)

if [[ -z $hangs_zookeeper && -z $hangs_master ]]; then
  #means no zookeeper and master instances exist.
  #normally terminate
  echo "stop hbase normally and successfully"
else 
  #kill java in master node
  pgrep java | while read aline; do echo "kill -9 $aline";  kill -9 $aline; done
  #kill java in regionservers/slave nodes
  index=0
  while [ $index -lt $num_regionservers ]; do
    hbase_regionserver_hostname=${hbase_regionserver_hostname_array[index]}
    ssh $hbase_user@$hbase_regionserver_hostname 'pgrep java | while read aline; do echo "kill -9 $aline";  kill -9 $aline; done'
    let index=index+1 
  done
fi 
 
#check result 
echo ":verify stop result" 
echo "@hmaster" 
jps 
index=0 
while [ $index -lt $num_regionservers ]; do 
  hbase_regionserver_hostname=${hbase_regionserver_hostname_array[index]} 
  echo "@regionserver: $hbase_regionserver_hostname" 
  ssh $hbase_user@$hbase_regionserver_hostname 'jps' 
  let index=index+1  
done 
 
