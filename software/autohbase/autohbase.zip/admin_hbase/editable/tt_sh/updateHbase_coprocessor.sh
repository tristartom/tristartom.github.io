#!/usr/bin/env bash
if [ $# -ne 1 ]; then
    echo -e "format: ./tt_sh/updateHbase_coprocessor.sh indexer_name[IndexObserverBaseline|IndexObserverwReadRepair|null]"
    echo -e "example: ./tt_sh/updateHbase_coprocessor.sh IndexObserverBaseline"
    echo "assumption: do use coprocessor.jar that exists in hdfs or vfs, cause when enabling table it will check jar file validity and load them. Otherwise, it stucks at enabling tables."
    exit 1
fi

indexer_class=$1

declare -A indexer_options #requiring bash -version 4+
indexer_options["IndexObserverwReadRepair"]="tthbase.coprocessor.IndexObserverwReadRepair"
indexer_options["IndexObserverBaseline"]="tthbase.coprocessor.IndexObserverBaseline"
indexer_options["null"]="null"

hdfs_namenode_hostname_unqualified=$(awk -F "=" '/^hdfs_namenode_hostname_unqualified=.*/ {print $2}' config.properties)
hbaseHdfs_coprocessorDirHdfs=$(awk -F "=" '/^hbaseHdfs_coprocessorDirHdfs=.*/ {print $2}' config.properties)
if [ ! -z $hbaseHdfs_coprocessorDirHdfs ]; then
  coprocessorLib_path="hdfs://$hdfs_namenode_hostname_unqualified:8020$hbaseHdfs_coprocessorDirHdfs"
else 
  coprocessorDir_localFs=$(awk -F "=" '/^coprocessorDir_localFs=.*/ {print $2}' config.properties)
  coprocessorLib_path="file:$coprocessorDir_localFs"
fi

coprocessorLib_name=libHbaseCoprocessor.jar
coprocessor_javaname=${indexer_options["$indexer_class"]}

./tt_sh/updateHbase_coprocessor_prim.sh $coprocessor_javaname "$coprocessorLib_path/$coprocessorLib_name" 2
