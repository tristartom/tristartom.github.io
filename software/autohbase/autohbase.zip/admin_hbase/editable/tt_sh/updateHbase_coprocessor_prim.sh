#!/usr/bin/env bash
if [ $# -ne 3 ]; then
    echo -e "format: ./tt_sh/updateHbase_coprocessor_prim.sh cp_fullClassName coprocessorLib_loc index_coprocessor"
    echo -e "debug_example_1: ./tt_sh/updateHbase_coprocessor_prim.sh tthbase.coprocessor.IndexObserverwReadRepair hdfs://node6:8020/hbase_cp/libHindex.jar 1"
    echo -e "debug_example_2: ./tt_sh/updateHbase_coprocessor_prim.sh tthbase.coprocessor.IndexObserverwReadRepair $(pwd)/../../sharedReadonly_hdfsAdmin/inputs/libHbaseCoprocessor.jar 1"
    echo -e "debug_example_3: ./tt_sh/updateHbase_coprocessor_prim.sh tthbase.coprocessor.TestPreCompact /home/yuzhe/workspace/research/intern_ibm2/tryProj/testCustomizeCompact_HBase0942/proj_customizeCompactScanner/build/jar/libPreScanner.jar 1"
    echo "assumption: do use coprocessor.jar that exists in hdfs or vfs, cause when enabling table it will check jar file validity and load them. Otherwise, it stucks at enabling tables."
    exit 1
fi

coprocessor_javaname=$1
coprocessorLib_loc=$2
coprocessor_index=$3

compile_updateCoprocessor=$(awk -F "=" '/^compile_updateCoprocessor=.*/ {print $2}' config.properties)

mainJavaname=UpdateCoprocessor
mainJavapathCompile=tthbase/util/$mainJavaname
mainJavapathRun=tthbase.util.$mainJavaname

build=./build
hbaseClientLib_path=$(pwd)/../inputs
CP=.
#no need for coprocessorLibXXX.jar in here
for f in $hbaseClientLib_path/*.jar; do
  CP=$CP:$f
done
CP=$CP:$build
if [ "$compile_updateCoprocessor" == 'true' ]; then
  echo "classpath="$CP
  javac -classpath "$CP" -sourcepath src -d $build src/$mainJavapathCompile.java
fi

#1)zkserver 2)zkserver_port  3)table_name 4)list of cfs in table, in a single {},separated by ,5) INDEX_CP_NAME 6) INDEX_CP_PATH 7) INDEX_CP_CLASS 8)-[list of index columns in the format of cfName|colName]
java -classpath "$CP" $mainJavapathRun \
localhost 2181 weblog {cf} coprocessor\$$coprocessor_index \
$coprocessorLib_loc \
$coprocessor_javaname \
cf\|country cf\|ip
#note: coprocessor\$1 is NOT referring to bash commandline argument
