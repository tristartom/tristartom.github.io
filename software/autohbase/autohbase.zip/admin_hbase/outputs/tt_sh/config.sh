#!/bin/bash
echo "./tt_sh/config.sh"

unzip hbaseAdminAndUtil_notYetConfigured.zip
rm -r ../editable 
mv editable ../

cp config.properties ../editable/config.properties
#additional properties
echo "compile_updateCoprocessor=false" >> ../editable/config.properties
