#!/bin/bash
config_file=config.properties
hbase_master_hostname_fullyqualified=$(awk -F "=" '/^hbase_master_hostname_fullyqualified=.*/ {print $2}' $config_file)
hbase_user=$(awk -F "=" '/^hbase_user=.*/ {print $2}' $config_file)
hbase_master_deployedProjAdminDir=$(awk -F "=" '/^hbase_master_deployedProjAdminDir=.*/ {print $2}' $config_file)
hbaseUtils_rootDir_fullPath="$hbase_user@$hbase_master_hostname_fullyqualified:${hbase_master_deployedProjAdminDir}"

if [[ $# -eq 1 && "$1" == '-help' ]]; then
  echo "./tt_sh/deploy.sh"
  exit
fi

ssh -t $hbase_user@$hbase_master_hostname_fullyqualified "mkdir -p ${hbase_master_deployedProjAdminDir}inputs/"
scp -r * ${hbaseUtils_rootDir_fullPath}inputs/
scp -r ../inputs/ ${hbaseUtils_rootDir_fullPath}

ssh -t $hbase_user@$hbase_master_hostname_fullyqualified ". "'~'"/.profile; cd ${hbase_master_deployedProjAdminDir}inputs/; ./tt_sh/config.sh"
