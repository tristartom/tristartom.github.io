#!/usr/bin/env bash

if [ $# -ne 0 ]; then
  echo -e "example: ./tt_sh/clean.sh"
  exit 1
fi

rm ../editable/ -rf
