#!/usr/bin/env bash
if [ $# -ne 0 ]; then 
  echo "config.sh only configure locally, it does not involves with deploying to other nodes"
  echo "example: ./tt_sh/config.sh"
  exit 1
fi

#creating relevant dirs
hbase_tt_dirname=hbase-configured
mkdir -p ../editable
rm -rf ../editable/$hbase_tt_dirname

cur_dir=$(pwd)
cd ../inputs
mkdir -p tmp
tar -zvxf hbase-* -C tmp
mv tmp/hbase-* ../editable/$hbase_tt_dirname
rm -rf tmp

#generate hbase-site.xml
config_file=config.properties
cd $cur_dir
mkdir -p ../editable/stores_zookeeperData

hbaseHdfs_dataDirHdfs=$(awk -F "=" '/^hbaseHdfs_dataDirHdfs=.*/ {print $2}' $config_file)
hdfs_namenode_hostname_unqualified=$(awk -F "=" '/^hdfs_namenode_hostname_unqualified=.*/ {print $2}' $config_file)
hbaseHdfs_dataUriHdfs="hdfs://$hdfs_namenode_hostname_unqualified:8020$hbaseHdfs_dataDirHdfs"
./tt_sh/ttconf/gen_hbaseSite.sh ../editable/$hbase_tt_dirname/conf/ $hbaseHdfs_dataUriHdfs $(pwd)/../editable/stores_zookeeperData

#config JAVA_HOME in hbase-env.sh 
java_home=$(awk -F "=" '/^java_home=.*/ {print $2}' $config_file)
echo "export JAVA_HOME=$java_home" >> ../editable/$hbase_tt_dirname/conf/hbase-env.sh
#toggle to let hbase manage zk
echo "export HBASE_MANAGES_ZK=true" >> ../editable/$hbase_tt_dirname/conf/hbase-env.sh
#enable JMX-base metrics system in HBase startup
echo -e "\
export HBASE_JMX_BASE=\"-Dcom.sun.management.jmxremote.ssl=false \
-Dcom.sun.management.jmxremote.authenticate=false\"\n\
export HBASE_MASTER_OPTS=\"\$HBASE_JMX_BASE \
-Dcom.sun.management.jmxremote.port=10101\"\n\
export HBASE_REGIONSERVER_OPTS=\"\$HBASE_JMX_BASE \
-Dcom.sun.management.jmxremote.port=10102\"\n\
export HBASE_THRIFT_OPTS=\"\$HBASE_JMX_BASE \
-Dcom.sun.management.jmxremote.port=10103\"\n\
export HBASE_ZOOKEEPER_OPTS=\"\$HBASE_JMX_BASE \
-Dcom.sun.management.jmxremote.port=10104\"\n\
" >> ../editable/$hbase_tt_dirname/conf/hbase-env.sh

#config region servers
./tt_sh/ttconf/gen_regionServers.sh $hbase_tt_dirname
