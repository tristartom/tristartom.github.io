#!/bin/bash
config_file=config.properties
hbase_master_hostname_fullyqualified=$(awk -F "=" '/^hbase_master_hostname_fullyqualified=.*/ {print $2}' $config_file)
hbase_user=$(awk -F "=" '/^hbase_user=.*/ {print $2}' $config_file)
hbase_all_deployedProjDir=$(awk -F "=" '/^hbase_all_deployedProjDir=.*/ {print $2}' $config_file)

if [ $# -ne 1 ] || [[ $# == 1 && "$1" == '-help' ]]; then
  echo "format: ./tt_sh/deploy.sh if_firsttime[first|else]"
  echo "debug_example_1: ./tt_sh/deploy.sh first"
  echo "debug_example_2: ./tt_sh/deploy.sh else"
  exit 1
fi

mode=$1
input_fullpath=$hbase_user@$hbase_master_hostname_fullyqualified:${hbase_all_deployedProjDir}inputs/

ssh $hbase_user@$hbase_master_hostname_fullyqualified "mkdir -p ${hbase_all_deployedProjDir}inputs/"
if [ "$mode" == 'first' ]; then
  ./tt_sh/deploy_firsttime.sh $input_fullpath
fi
scp -r * $input_fullpath

ssh -t $hbase_user@$hbase_master_hostname_fullyqualified ". ~/.profile; cd ${hbase_all_deployedProjDir}inputs/; ./tt_sh/config.sh"
ssh -t $hbase_user@$hbase_master_hostname_fullyqualified ". ~/.profile; cd ${hbase_all_deployedProjDir}inputs/; ./tt_sh/deployFromMasterToMultiSlaves.sh $mode"
