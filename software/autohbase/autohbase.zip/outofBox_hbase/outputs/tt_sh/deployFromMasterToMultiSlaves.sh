#!/usr/bin/env bash
config_file=config.properties
hbase_regionserver_hostnames=$(awk -F "=" '/^hbase_regionserver_hostnames=.*/ {print $2}' $config_file)
IFS=':' read -ra hbase_regionserver_hostname_array <<< "$hbase_regionserver_hostnames"
num_regionservers=${#hbase_regionserver_hostname_array[@]}

if [ $# -ne 1 ] || [[ $# -eq 1 && "$1" == '-help' ]]; then
  echo -e "format: ./tt_sh/deployFromMasterToMultiSlaves.sh [first|else]"
  echo -e "debug_example_1: ./tt_sh/deployFromMasterToMultiSlaves.sh first"
  echo -e "debug_example_2: ./tt_sh/deployFromMasterToMultiSlaves.sh second"
  exit 1
fi

mode=$1

index=0
while [ $index -lt $num_regionservers ]; do
  hbase_regionserver_hostname=${hbase_regionserver_hostname_array[index]}
  ./tt_sh/deployFromMasterToSlave.sh $mode $hbase_regionserver_hostname
  let index=index+1 
done
