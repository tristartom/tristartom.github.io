#!/usr/bin/env bash
config_file=config.properties
hbase_user=$(awk -F "=" '/^hbase_user=.*/ {print $2}' $config_file)
hbase_all_deployedProjDir=$(awk -F "=" '/^hbase_all_deployedProjDir=.*/ {print $2}' $config_file)

if [ $# -ne 2 ]; then
  echo -e "./tt_sh/deployFromMasterToSlave.sh mode regionserver_hostname"
  echo -e "./tt_sh/deployFromMasterToSlave.sh first node4"
  echo "first-time setup dirs on all nodes to deploy: mkdir ${hbase_all_deployedProjDir}inputs "
  exit 1
fi

mode=$1
hbase_regionserver_hostname=$2

input_fullpath=$hbase_user@$hbase_regionserver_hostname:${hbase_all_deployedProjDir}inputs/

ssh $hbase_user@$hbase_regionserver_hostname "mkdir -p ${hbase_all_deployedProjDir}inputs/"
if [ "$mode" == 'first' ]; then
  ./tt_sh/deploy_firsttime.sh $input_fullpath
fi
scp -r * $input_fullpath

ssh -t $hbase_user@$hbase_regionserver_hostname ". ~/.profile; cd ${hbase_all_deployedProjDir}inputs/; ./tt_sh/config.sh"

