#!/usr/bin/env bash
if [[ $# == 1 && "$1" == '-help' ]]; then
  echo "debug_example: ./tt_sh/deploy_firsttime.sh"
  exit 1
fi

deployed_fullpath="$1"
scp -r ../inputs/* $deployed_fullpath
