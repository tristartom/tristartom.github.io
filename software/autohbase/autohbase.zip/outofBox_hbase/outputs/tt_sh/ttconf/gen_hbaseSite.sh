#!/usr/bin/env bash
if [ $# -ne 3 ] || [[ $# -eq 1 && "$1" == '-help' ]]; then
  echo "format:./tt_sh/ttconf/gen_hbaseSite.sh dir_output data_fulldir_inhdfs dir_zookeeperStore"
  echo "debug_example:./tt_sh/ttconf/gen_hbaseSite.sh ./ hdfs://node6.hindex-11nodes.vprj.emulab.net:8020/hbase /mnt/tt/sharedReadonly_hbaseOutOfBox/editable/stores_zookeeperData"
  exit 1
fi

dir_output=$1

#obtain the canonical address of the MASTER machine.
#TOREMOVE make sure the domain name follows pattern .*[^\.]+\.[^0-9]+.*
config_file=config.properties
hbase_master_hostname_fullyqualified=$(awk -F "=" '/^hbase_master_hostname_fullyqualified=.*/ {print $2}' $config_file)
hbase_master_hostname_unqualified=$(awk -F "=" '/^hbase_master_hostname_unqualified=.*/ {print $2}' $config_file)
cp tt_sh/ttconf/hbase-site_disableCompact_partial_TEMPLATE.xml ./hbase-site.xml
echo -e "  <property>\n    <name>dfs.replication</name>\n    <value>1</value>\n  </property>\n" >> hbase-site.xml
#ending pattern (\s+|$) is used to avoid appearance of node10 being matched with node1
ip_address=$(grep -P "\s+$hbase_master_hostname_unqualified(\s+|$)" /etc/hosts | awk '{print $1}')
#canonical_name=$(ping -c 1 $hbase_master_hostname | awk -F " " '/.*[^\.]+\.[^0-9]+.*/ {match($0, /[^ \t]+\.[^\.]+\.[^0-9]+[ \t]/); print substr($0, RSTART, RLENGTH - 1); exit}')

echo -e "  <property>\n    <name>hbase.zookeeper.quorum</name>\n    <value>$ip_address</value>\n  </property>\n" >> hbase-site.xml

#more properly, should be "using-vfs"
if [ ! "$hbase_master_hostname_fullyqualified" == 'localhost' ]; then
  dataDir_inHdfs=$2
  echo -e "  <property>\n    <name>hbase.rootdir</name>\n    <value>$dataDir_inHdfs</value>\n  </property>\n" >> hbase-site.xml
else
  dataDir_local="$(pwd)/../editable/stores_dataTest"
  mkdir -p $dataDir_local
  echo -e "  <property>\n    <name>hbase.rootdir</name>\n    <value>file:///$dataDir_local</value>\n  </property>\n" >> hbase-site.xml
fi

echo -e "  <property>\n    <name>hbase.cluster.distributed</name>\n    <value>true</value>\n  </property>\n" >> hbase-site.xml

storeDir_zookeeper=$3
echo -e "  <property>\n    <name>hbase.zookeeper.property.dataDir</name>\n    <value>$storeDir_zookeeper</value>\n  </property>" >> hbase-site.xml

echo '</configuration>' >> hbase-site.xml
mv hbase-site.xml $dir_output
