#!/usr/bin/env bash
config_file=config.properties
hbase_regionserver_hostnames=$(awk -F "=" '/^hbase_regionserver_hostnames=.*/ {print $2}' $config_file)
IFS=':' read -ra hbase_regionserver_hostname_array <<< "$hbase_regionserver_hostnames"
num_regionservers=${#hbase_regionserver_hostname_array[@]}

if [ $# -ne 1 ] || [[ $# -eq 1 && "$1" == '-help' ]]; then
  echo -e "format: ./tt_sh/ttconf/gen_regionServers.sh hbase_tt_dirname"
  echo -e "debug_example: ./tt_sh/ttconf/gen_regionServers.sh hbase.92.1-configured"
  exit 1
fi

hbase_tt_dirname=$1
text_slaves=""
index=0
while [ $index -lt $num_regionservers ]; do
  hbase_regionserver_hostname=${hbase_regionserver_hostname_array[index]}
  text_slaves=${text_slaves}"$hbase_regionserver_hostname\n"
  let index=index+1 
done

#note slave file don't need to sync to slave nodes (regionservers).
echo -e $text_slaves > ../editable/$hbase_tt_dirname/conf/regionservers
