#!/usr/bin/env bash
configFile_selected=config_vfs.properties
cp $configFile_selected ./outofBox_hbase/outputs/config.properties
cp $configFile_selected ./admin_hbase/outputs/config.properties
