#!/usr/bin/env bash
cd ./outofBox_hbase/outputs/; ./tt_sh/deploy.sh first; cd ../..
cd ./admin_hbase/outputs/; ./tt_sh/deploy.sh; cd ../..


